/**
 * Google Apps Script for Cyber Security Club Recruitment Form
 * Production Version - Ready for deployment
 * This script handles form submissions and sends confirmation emails
 * Enhanced with authority notification feature
 */
const CONFIG = {
  SPREADSHEET_ID: '1jI9g4BOgN946wgIneiNw6r0sBmloijNsPHexuxi77zY',
  FROM_EMAIL: 'pranto.ks@uttarauniversity.edu.bd',
  FROM_NAME: 'Cyber Security Club - Uttara University',
  SUBJECT: 'Application Received - Cyber Security Club',
  AUTHORITY_EMAILS: [
    'pranto.ks@uttarauniversity.edu.bd',
    'cybersecurity@club.uttara.ac.bd'
  ],
  AUTHORITY_SUBJECT: 'New Application Received - CSC Recruitment'
};

function doPost(e) {
  try {
    // Get the active spreadsheet
    var spreadsheet = SpreadsheetApp.openById(CONFIG.SPREADSHEET_ID);
    var sheet = spreadsheet.getActiveSheet();
    
    // Parse the incoming data
    var data = JSON.parse(e.postData.contents);
    
    // Add headers if this is the first row
    if (sheet.getLastRow() === 0) {
      var headers = [
        'Timestamp', 'First Name', 'Last Name', 'Student ID', 'Batch', 
        'Section', 'Department', 'Phone', 'Email', 'Experience', 
        'Interests', 'Motivation', 'Role', 'Availability', 'Skills', 'Agreement'
      ];
      sheet.getRange(1, 1, 1, headers.length).setValues([headers]);
      
      // Format headers
      sheet.getRange(1, 1, 1, headers.length)
        .setBackground('#4285F4')
        .setFontColor('#FFFFFF')
        .setFontWeight('bold');
    }
    
    // Add the data to the sheet
    var rowData = [
      data.timestamp || new Date().toISOString(),
      data.firstName,
      data.lastName,
      data.studentId,
      data.batch,
      data.section,
      data.department,
      data.phone,
      data.email,
      data.experience,
      data.interests,
      data.motivation,
      data.role,
      data.availability,
      data.skills,
      data.agreement
    ];
    
    sheet.appendRow(rowData);
    
    // Send confirmation email to applicant
    try {
      sendConfirmationEmail(data);
      console.log('Confirmation email sent to:', data.email);
    } catch (emailError) {
      console.error('Error sending confirmation email:', emailError);
      // Continue with success response even if email fails
    }
    
    // Send notification email to authorities
    try {
      sendAuthorityNotification(data);
      console.log('Authority notification emails sent');
    } catch (authorityEmailError) {
      console.error('Error sending authority notification:', authorityEmailError);
      // Continue with success response even if authority notification fails
    }
    
    return ContentService
      .createTextOutput(JSON.stringify({success: true, message: 'Application submitted successfully. Confirmation email sent to applicant and authorities notified.'}))
      .setMimeType(ContentService.MimeType.JSON);
      
  } catch (error) {
    console.error('Error processing application:', error);
    return ContentService
      .createTextOutput(JSON.stringify({success: false, message: error.toString()}))
      .setMimeType(ContentService.MimeType.JSON);
  }
}

/**
 * Send confirmation email to the applicant
 */
function sendConfirmationEmail(data) {
  try {
    console.log('📧 Starting sendConfirmationEmail for:', data.email);
    console.log('⚙️ Using CONFIG:', JSON.stringify(CONFIG, null, 2));
    
    console.log('🎨 Creating email template...');
    const emailTemplate = createEmailTemplate(data);
    console.log('✅ Email template created, length:', emailTemplate.length);
    
    console.log('📤 Preparing to send email with MailApp...');
    const emailOptions = {
      to: data.email,
      subject: CONFIG.SUBJECT,
      htmlBody: emailTemplate,
      name: CONFIG.FROM_NAME,
      replyTo: CONFIG.FROM_EMAIL
    };
    console.log('📋 Email options:', JSON.stringify(emailOptions, null, 2));
    
    console.log('🚀 Sending email via MailApp...');
    MailApp.sendEmail(emailOptions);
    
    console.log('✅ Confirmation email sent successfully to:', data.email);
    
  } catch (error) {
    console.error('❌ Error in sendConfirmationEmail - Step details:');
    console.error('❌ Target email:', data.email);
    console.error('❌ Error message:', error.message);
    console.error('❌ Error type:', error.name);
    console.error('❌ Full error:', error);
    console.error('❌ Stack trace:', error.stack);
    throw error;
  }
}

/**
 * Send notification email to authorities when new application is received
 */
function sendAuthorityNotification(data) {
  try {
    console.log('🔔 Starting sendAuthorityNotification...');
    console.log('👥 Authority emails:', CONFIG.AUTHORITY_EMAILS);
    
    const authorityTemplate = createAuthorityEmailTemplate(data);
    console.log('✅ Authority email template created');
    
    // Send to each authority email
    CONFIG.AUTHORITY_EMAILS.forEach(email => {
      console.log('📤 Sending notification to authority:', email);
      
      const emailOptions = {
        to: email,
        subject: CONFIG.AUTHORITY_SUBJECT,
        htmlBody: authorityTemplate,
        name: CONFIG.FROM_NAME,
        replyTo: CONFIG.FROM_EMAIL
      };
      
      MailApp.sendEmail(emailOptions);
      console.log('✅ Authority notification sent to:', email);
    });
    
    console.log('✅ All authority notifications sent successfully');
    
  } catch (error) {
    console.error('❌ Error in sendAuthorityNotification:');
    console.error('❌ Error message:', error.message);
    console.error('❌ Full error:', error);
    throw error;
  }
}

/**
 * Create HTML email template for applicant confirmation
 */
function createEmailTemplate(data) {
  const fullName = `${data.firstName} ${data.lastName}`;
  const currentDate = new Date().toLocaleDateString('en-US', {
    year: 'numeric',
    month: 'long',
    day: 'numeric'
  });
  
  return `
<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Application Confirmation - Cyber Security Club</title>
</head>
<body style="margin: 0; padding: 0; font-family: Arial, sans-serif; line-height: 1.6; background-color: #f5f5f5;">
    <div style="max-width: 650px; margin: 0 auto; background-color: #ffffff; border-radius: 10px; overflow: hidden; box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);">
        
        <!-- Header -->
        <div style="background-color: #ffffff; padding: 20px; text-align: center;">
            <img src="https://cybersecurity.club.uttara.ac.bd/assets/images/csc_blue.png" alt="Cyber Security Club Logo" style="width: 300px; height: auto;">
        </div>
        
        <!-- Content -->
        <div style="padding: 30px; background-color: #ffffff;">
            
            <!-- Success Badge -->
            <div style="background-color: #1e1e77; color: white; padding: 10px 15px; border-radius: 8px; font-weight: 600; font-size: 16px; margin-bottom: 25px; text-align: center;">
                Application Received Successfully!
            </div>
            
            <!-- Greeting -->
            <div style="font-size: 18px; color: #1f2937; margin-bottom: 20px; font-weight: 500;">
                Dear <strong>${fullName}</strong>,
            </div>
            
            <!-- Message -->
            <div style="color: #4b5563; margin-bottom: 25px; line-height: 1.7;">
                We have successfully received your application to join the <strong>Cyber Security Club</strong>. We're excited about your interest in cybersecurity and look forward to potentially welcoming you to our community of passionate security enthusiasts!
            </div>
            
            <!-- Application Details -->
            <div style="background-color: #f8fafc; border: 1px solid #e2e8f0; border-left: 4px solid #3b82f6; border-radius: 8px; padding: 20px; margin: 20px 0;">
                <h3 style="color: #1e40af; font-size: 18px; font-weight: 700; margin: 0 0 15px 0;">Application Summary</h3>
                
                <table style="width: 100%; border-collapse: collapse;">
                    <tr>
                        <td style="padding: 10px 0; border-bottom: 1px solid #e5e7eb; font-weight: 600; color: #374151;">Application Date</td>
                        <td style="padding: 10px 0; border-bottom: 1px solid #e5e7eb; color: #1d4ed8; font-weight: 500; text-align: right;">${currentDate}</td>
                    </tr>
                    <tr>
                        <td style="padding: 10px 0; border-bottom: 1px solid #e5e7eb; font-weight: 600; color: #374151;">Student ID</td>
                        <td style="padding: 10px 0; border-bottom: 1px solid #e5e7eb; color: #1d4ed8; font-weight: 500; text-align: right;">${data.studentId}</td>
                    </tr>
                    <tr>
                        <td style="padding: 10px 0; border-bottom: 1px solid #e5e7eb; font-weight: 600; color: #374151;">Contact Number</td>
                        <td style="padding: 10px 0; border-bottom: 1px solid #e5e7eb; color: #1d4ed8; font-weight: 500; text-align: right;">${data.phone}</td>
                    </tr>
                    <tr>
                        <td style="padding: 10px 0; border-bottom: 1px solid #e5e7eb; font-weight: 600; color: #374151;">Department</td>
                        <td style="padding: 10px 0; border-bottom: 1px solid #e5e7eb; color: #1d4ed8; font-weight: 500; text-align: right;">${data.department}</td>
                    </tr>
                    <tr>
                        <td style="padding: 10px 0; border-bottom: 1px solid #e5e7eb; font-weight: 600; color: #374151;">Batch & Section</td>
                        <td style="padding: 10px 0; border-bottom: 1px solid #e5e7eb; color: #1d4ed8; font-weight: 500; text-align: right;">Batch ${data.batch}, Section ${data.section}</td>
                    </tr>
                    <tr>
                        <td style="padding: 10px 0; border-bottom: 1px solid #e5e7eb; font-weight: 600; color: #374151;">Preferred Role</td>
                        <td style="padding: 10px 0; border-bottom: 1px solid #e5e7eb; color: #1d4ed8; font-weight: 500; text-align: right;">${data.role}</td>
                    </tr>
                    <tr>
                        <td style="padding: 10px 0; font-weight: 600; color: #374151;">Experience Level</td>
                        <td style="padding: 10px 0; color: #1d4ed8; font-weight: 500; text-align: right;">${data.experience}</td>
                    </tr>
                </table>
            </div>
            
            <!-- Next Steps -->
            <div style="background-color: #eff6ff; border: 1px solid #bfdbfe; border-radius: 8px; padding: 20px; margin: 20px 0;">
                <h3 style="color: #1e40af; font-size: 18px; font-weight: 700; margin: 0 0 15px 0;">What Happens Next?</h3>
                
                <div style="margin: 10px 0;">
                    <div style="display: inline-block; width: 25px; height: 25px; background-color: #3b82f6; color: white; border-radius: 50%; text-align: center; line-height: 25px; font-weight: bold; font-size: 12px; margin-right: 10px; vertical-align: top;">1</div>
                    <span style="color: #374151; font-size: 14px;">Our team will review your application within 3-5 days</span>
                </div>
                
                <div style="margin: 10px 0;">
                    <div style="display: inline-block; width: 25px; height: 25px; background-color: #3b82f6; color: white; border-radius: 50%; text-align: center; line-height: 25px; font-weight: bold; font-size: 12px; margin-right: 10px; vertical-align: top;">2</div>
                    <span style="color: #374151; font-size: 14px;">You'll receive an email invitation to our next Meet & Greet session</span>
                </div>
                
                <div style="margin: 10px 0;">
                    <div style="display: inline-block; width: 25px; height: 25px; background-color: #3b82f6; color: white; border-radius: 50%; text-align: center; line-height: 25px; font-weight: bold; font-size: 12px; margin-right: 10px; vertical-align: top;">3</div>
                    <span style="color: #374151; font-size: 14px;">Attend the informal meeting to learn more about our club activities</span>
                </div>
                
                <div style="margin: 10px 0;">
                    <div style="display: inline-block; width: 25px; height: 25px; background-color: #3b82f6; color: white; border-radius: 50%; text-align: center; line-height: 25px; font-weight: bold; font-size: 12px; margin-right: 10px; vertical-align: top;">4</div>
                    <span style="color: #374151; font-size: 14px;">Join our social media groups to connect with other members</span>
                </div>
                
                <div style="margin: 10px 0;">
                    <div style="display: inline-block; width: 25px; height: 25px; background-color: #3b82f6; color: white; border-radius: 50%; text-align: center; line-height: 25px; font-weight: bold; font-size: 12px; margin-right: 10px; vertical-align: top;">5</div>
                    <span style="color: #374151; font-size: 14px;">Start participating in club activities and workshops!</span>
                </div>
            </div>
            
            <!-- Important Note -->
            <div style="background-color: #fef3c7; border: 1px solid #f59e0b; border-radius: 8px; padding: 15px; margin: 20px 0; color: #92400e; font-size: 14px;">
                <strong>Important:</strong> Please save this email for your records. You may need to reference your application details during the review process.
            </div>
            
            <!-- Signature -->
            <div style="margin-top: 25px; padding-top: 20px; border-top: 2px solid #f1f5f9; color: #374151; line-height: 1.7;">
                We appreciate your interest in cybersecurity and look forward to potentially having you as part of our cybersecurity family!<br><br>
                Best regards,<br>
                <strong>The Cyber Security Club Team</strong><br>
                Uttara University
            </div>
        </div>
        
        <!-- Footer -->
        <div style="background-color: #1e293b; color: #e2e8f0; padding: 20px; text-align: center; font-size: 13px;">
            <div>© 2025 Cyber Security Club, Uttara University</div>
            <div style="margin-top: 10px; opacity: 0.8;">This is an automated message. Please do not reply directly to this email.</div>
            <div style="margin-top: 10px;;">
                <a href="https://facebook.com/csc.uu.bd" style="display: inline-block;color: white; text-decoration: none; margin-left: 10px; margin-right: 10px;">Facebook</a>
                <a href="https://www.linkedin.com/in/cscuu" style="display: inline-block;color: white; text-decoration: none; margin-left: 10px; margin-right: 10px;">LinkedIn</a>
                <a href="https://discord.gg/N83SjBHjzG" style="display: inline-block;color: white; text-decoration: none; margin-left: 10px; margin-right: 10px;">Discord</a>
            </div>
        </div>
    </div>
</body>
</html>`;
}

/**
 * Create HTML email template for authority notification
 */
function createAuthorityEmailTemplate(data) {
  const fullName = `${data.firstName} ${data.lastName}`;
  const currentDate = new Date().toLocaleDateString('en-US', {
    year: 'numeric',
    month: 'long',
    day: 'numeric'
  });
  const currentTime = new Date().toLocaleTimeString('en-US', {
    hour: '2-digit',
    minute: '2-digit'
  });
  
  return `
<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>New Application Alert - CSC Recruitment</title>
</head>
<body style="margin: 0; padding: 0; font-family: Arial, sans-serif; line-height: 1.6; background-color: #f5f5f5;">
    <div style="max-width: 700px; margin: 0 auto; background-color: #ffffff; border-radius: 10px; overflow: hidden; box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);">
        
        <!-- Header -->
        <div style="background-color: #dc2626; color: white; padding: 20px; text-align: center;">
            <h1 style="margin: 0; font-size: 24px; font-weight: 700;">🔔 New Application Alert</h1>
            <p style="margin: 5px 0 0 0; font-size: 16px; opacity: 0.9;">Cyber Security Club Recruitment</p>
        </div>
        
        <!-- Content -->
        <div style="padding: 30px; background-color: #ffffff;">
            
            <!-- Alert Badge -->
            <div style="background-color: #059669; color: white; padding: 12px 20px; border-radius: 8px; font-weight: 600; font-size: 16px; margin-bottom: 25px; text-align: center;">
                New Member Application Received
            </div>
            
            <!-- Notification Message -->
            <div style="background-color: #f0f9ff; border: 1px solid #0284c7; border-left: 4px solid #0284c7; border-radius: 8px; padding: 20px; margin-bottom: 25px;">
                <h3 style="color: #0369a1; font-size: 18px; font-weight: 700; margin: 0 0 10px 0;">📋 Application Summary</h3>
                <p style="color: #075985; margin: 0; font-size: 16px;">
                    <strong>${fullName}</strong> has submitted an application to join the Cyber Security Club on <strong>${currentDate}</strong> at <strong>${currentTime}</strong>.
                </p>
            </div>
            
            <!-- Applicant Details -->
            <div style="background-color: #fafafa; border: 1px solid #e5e7eb; border-radius: 8px; padding: 25px; margin: 20px 0;">
                <h3 style="color: #374151; font-size: 20px; font-weight: 700; margin: 0 0 20px 0;">👤 Applicant Information</h3>
                
                <table style="width: 100%; border-collapse: collapse;">
                    <tr>
                        <td style="padding: 12px 0; border-bottom: 1px solid #d1d5db; font-weight: 600; color: #374151; width: 35%;">Full Name</td>
                        <td style="padding: 12px 0; border-bottom: 1px solid #d1d5db; color: #1f2937; font-weight: 500;">${fullName}</td>
                    </tr>
                    <tr>
                        <td style="padding: 12px 0; border-bottom: 1px solid #d1d5db; font-weight: 600; color: #374151;">Student ID</td>
                        <td style="padding: 12px 0; border-bottom: 1px solid #d1d5db; color: #1f2937; font-weight: 500;">${data.studentId}</td>
                    </tr>
                    <tr>
                        <td style="padding: 12px 0; border-bottom: 1px solid #d1d5db; font-weight: 600; color: #374151;">Email</td>
                        <td style="padding: 12px 0; border-bottom: 1px solid #d1d5db; color: #1f2937; font-weight: 500;"><a href="mailto:${data.email}" style="color: #2563eb; text-decoration: none;">${data.email}</a></td>
                    </tr>
                    <tr>
                        <td style="padding: 12px 0; border-bottom: 1px solid #d1d5db; font-weight: 600; color: #374151;">Phone</td>
                        <td style="padding: 12px 0; border-bottom: 1px solid #d1d5db; color: #1f2937; font-weight: 500;"><a href="tel:${data.phone}" style="color: #2563eb; text-decoration: none;">${data.phone}</a></td>
                    </tr>
                    <tr>
                        <td style="padding: 12px 0; border-bottom: 1px solid #d1d5db; font-weight: 600; color: #374151;">Department</td>
                        <td style="padding: 12px 0; border-bottom: 1px solid #d1d5db; color: #1f2937; font-weight: 500;">${data.department}</td>
                    </tr>
                    <tr>
                        <td style="padding: 12px 0; border-bottom: 1px solid #d1d5db; font-weight: 600; color: #374151;">Batch & Section</td>
                        <td style="padding: 12px 0; border-bottom: 1px solid #d1d5db; color: #1f2937; font-weight: 500;">Batch ${data.batch}, Section ${data.section}</td>
                    </tr>
                    <tr>
                        <td style="padding: 12px 0; border-bottom: 1px solid #d1d5db; font-weight: 600; color: #374151;">Preferred Role</td>
                        <td style="padding: 12px 0; border-bottom: 1px solid #d1d5db; color: #1f2937; font-weight: 500;"><span style="background-color: #dbeafe; color: #1e40af; padding: 4px 8px; border-radius: 4px; font-size: 14px;">${data.role}</span></td>
                    </tr>
                    <tr>
                        <td style="padding: 12px 0; border-bottom: 1px solid #d1d5db; font-weight: 600; color: #374151;">Experience Level</td>
                        <td style="padding: 12px 0; border-bottom: 1px solid #d1d5db; color: #1f2937; font-weight: 500;"><span style="background-color: #dcfce7; color: #166534; padding: 4px 8px; border-radius: 4px; font-size: 14px;">${data.experience}</span></td>
                    </tr>
                    <tr>
                        <td style="padding: 12px 0; font-weight: 600; color: #374151;">Availability</td>
                        <td style="padding: 12px 0; color: #1f2937; font-weight: 500;">${data.availability}</td>
                    </tr>
                </table>
            </div>
            
            <!-- Additional Information -->
            <table style="width: 100%; margin: 20px 0; border-collapse: collapse;">
                <tr>
                    <td style="width: 48%; vertical-align: top; padding-right: 10px;">
                        <div style="background-color: #f8fafc; border: 1px solid #e2e8f0; border-radius: 8px; padding: 20px;">
                            <h4 style="color: #475569; font-size: 16px; font-weight: 700; margin: 0 0 10px 0;">🎯 Areas of Interest</h4>
                            <p style="color: #64748b; margin: 0; font-size: 14px; line-height: 1.5;">${data.interests}</p>
                        </div>
                    </td>
                    <td style="width: 48%; vertical-align: top; padding-left: 10px;">
                        <div style="background-color: #f8fafc; border: 1px solid #e2e8f0; border-radius: 8px; padding: 20px;">
                            <h4 style="color: #475569; font-size: 16px; font-weight: 700; margin: 0 0 10px 0;">💪 Skills</h4>
                            <p style="color: #64748b; margin: 0; font-size: 14px; line-height: 1.5;">${data.skills}</p>
                        </div>
                    </td>
                </tr>
            </table>
            
            <!-- Motivation -->
            <div style="background-color: #fefce8; border: 1px solid #facc15; border-left: 4px solid #eab308; border-radius: 8px; padding: 20px; margin: 20px 0;">
                <h4 style="color: #a16207; font-size: 16px; font-weight: 700; margin: 0 0 10px 0;">💭 Motivation</h4>
                <p style="color: #92400e; margin: 0; font-style: italic; line-height: 1.6;">"${data.motivation}"</p>
            </div>
            
            <!-- Quick Actions -->
            <div style="background-color: #eff6ff; border: 1px solid #bfdbfe; border-radius: 8px; padding: 20px; margin: 20px 0;">
                <h3 style="color: #1e40af; font-size: 18px; font-weight: 700; margin: 0 0 15px 0;">⚡ Quick Actions</h3>
                
                <table style="width: 100%; border-collapse: collapse;">
                    <tr>
                        <td style="padding: 5px;">
                            <a href="mailto:${data.email}?subject=Re: Your Application to Cyber Security Club" style="background-color: #3b82f6; color: white; padding: 10px 20px; text-decoration: none; border-radius: 6px; font-weight: 600; font-size: 14px; display: inline-block; width: 100%; text-align: center; box-sizing: border-box;">📧 Contact Applicant</a>
                        </td>
                    </tr>
                    <tr>
                        <td style="padding: 5px;">
                            <a href="https://docs.google.com/spreadsheets/d/${CONFIG.SPREADSHEET_ID}" target="_blank" style="background-color: #059669; color: white; padding: 10px 20px; text-decoration: none; border-radius: 6px; font-weight: 600; font-size: 14px; display: inline-block; width: 100%; text-align: center; box-sizing: border-box;">📊 View Spreadsheet</a>
                        </td>
                    </tr>
                    <tr>
                        <td style="padding: 5px;">
                            <a href="tel:${data.phone}" style="background-color: #7c3aed; color: white; padding: 10px 20px; text-decoration: none; border-radius: 6px; font-weight: 600; font-size: 14px; display: inline-block; width: 100%; text-align: center; box-sizing: border-box;">📞 Call Applicant</a>
                        </td>
                    </tr>
                </table>
            </div>
            
            <!-- System Note -->
            <div style="margin-top: 25px; padding-top: 20px; border-top: 2px solid #f1f5f9; color: #6b7280; line-height: 1.7; font-size: 14px;">
                <strong>📝 Note:</strong> This application has been automatically saved to the recruitment spreadsheet. A confirmation email has also been sent to the applicant.<br><br>
                <strong>Next Steps:</strong> Review the application and contact the student within 3-5 business days as per club policy.
            </div>
        </div>
        
        <!-- Footer -->
        <div style="background-color: #1e293b; color: #e2e8f0; padding: 20px; text-align: center; font-size: 13px;">
            <div style="font-weight: 600;">Cyber Security Club - Recruitment Management System</div>
            <div style="margin-top: 10px; opacity: 0.8;">Generated on ${currentDate} at ${currentTime}</div>
            <div style="margin-top: 10px; opacity: 0.7;">This is an automated notification email</div>
        </div>
    </div>
</body>
</html>`;
}

/**
 * TESTING FUNCTIONS - Use these to test email functionality
 * Run these functions in Google Apps Script to verify everything works
 */

/**
 * STEP 1: Test basic email functionality first
 */
function testBasicEmail() {
  try {
    MailApp.sendEmail({
      to: 'prantokumar.net@gmail.com',
      subject: 'Test Email - CSC Recruitment System',
      body: 'Hello! This is a test to verify basic email functionality is working. If you receive this, the system is ready!'
    });
    
    console.log('✅ Basic email test successful');
    return 'Basic email sent successfully!';
    
  } catch (error) {
    console.error('❌ Basic email test failed:', error);
    return 'Basic email failed: ' + error.toString();
  }
}

/**
 * STEP 2: Test authority notification email with simplified template
 */
function testAuthorityNotification() {
  try {
    console.log('🧪 Starting authority notification test...');
    
    const testData = {
      firstName: 'John',
      lastName: 'Doe',
      studentId: 'UU-2025-001',
      department: 'Computer Science & Engineering',
      batch: '60',
      section: 'B',
      role: 'Active Member',
      experience: 'Intermediate',
      email: 'john.doe@student.uttara.ac.bd',
      phone: '+8801987654321',
      interests: 'Penetration testing, Malware analysis, Cryptography',
      motivation: 'I am passionate about cybersecurity and want to contribute to protecting our digital world.',
      skills: 'Python, JavaScript, Kali Linux, Wireshark',
      availability: 'Flexible schedule, prefer evening sessions'
    };
    
    console.log('📝 Test data prepared for authority notification');
    
    console.log('🔔 Sending authority notification...');
    sendAuthorityNotification(testData);
    console.log('✅ Authority notification test successful');
    return 'Authority notification sent successfully!';
    
  } catch (error) {
    console.error('❌ Authority notification test failed:', error.message);
    console.error('❌ Full error details:', error);
    return 'Authority notification failed: ' + error.toString();
  }
}

/**
 * STEP 3: Test complete application flow
 */
function testCompleteFlow() {
  try {
    console.log('🧪 Starting complete application flow test...');
    
    const testData = {
      firstName: 'Alice',
      lastName: 'Smith',
      studentId: 'UU-2025-002',
      department: 'Information Technology',
      batch: '59',
      section: 'A',
      role: 'Research Member',
      experience: 'Advanced',
      email: 'prantokumar.net@gmail.com', // Using your test email
      phone: '+8801555123456',
      interests: 'AI security, Blockchain security, IoT security',
      motivation: 'I want to research emerging security threats and develop innovative solutions.',
      skills: 'Machine Learning, Smart Contracts, Python, C++',
      availability: 'Research sessions preferred',
      agreement: 'yes'
    };
    
    console.log('📝 Test data prepared for complete flow');
    
    // Test applicant confirmation
    console.log('📧 Sending applicant confirmation...');
    sendConfirmationEmail(testData);
    console.log('✅ Applicant confirmation sent');
    
    // Test authority notification
    console.log('🔔 Sending authority notification...');
    sendAuthorityNotification(testData);
    console.log('✅ Authority notification sent');
    
    console.log('✅ Complete application flow test successful');
    return 'Complete application flow test passed!';
    
  } catch (error) {
    console.error('❌ Complete application flow test failed:', error.message);
    console.error('❌ Full error details:', error);
    return 'Complete flow test failed: ' + error.toString();
  }
}

/**
 * Check email quota and permissions
 */
function checkEmailStatus() {
  try {
    const quota = MailApp.getRemainingDailyQuota();
    console.log('📊 Daily email quota remaining:', quota);
    
    return `Email system status: Active | Quota remaining: ${quota} emails`;
    
  } catch (error) {
    console.error('❌ Error checking email status:', error);
    return 'Email status check failed: ' + error.toString();
  }
}

/**
 * RUN THIS FUNCTION FIRST - Quick debug test
 * This will test basic functionality and show detailed logs
 */
function quickDebugTest() {
  console.log('🚀 Starting quick debug test...\n');
  
  try {
    // Test 1: Check email quota
    console.log('📊 Test 1: Email Status Check...');
    const statusResult = checkEmailStatus();
    console.log('Result:', statusResult);
    console.log('---\n');
    
    // Test 2: Basic email
    console.log('📧 Test 2: Basic Email...');
    const basicResult = testBasicEmail();
    console.log('Result:', basicResult);
    console.log('---\n');
    
    // Test 3: Authority notification only
    console.log('🔔 Test 3: Authority Notification...');
    const authorityResult = testAuthorityNotification();
    console.log('Result:', authorityResult);
    console.log('---\n');
    
    console.log('✅ Quick debug test completed! Check the logs above for any errors.');
    return 'Quick debug test completed successfully!';
    
  } catch (error) {
    console.error('❌ Quick debug test failed:', error);
    return 'Quick debug test failed: ' + error.toString();
  }
}

