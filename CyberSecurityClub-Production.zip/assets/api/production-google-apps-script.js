/**
 * Google Apps Script for Cyber Security Club Recruitment Form
 * Production Version - Ready for deployment
 * This script handles form submissions and sends confirmation emails
 */

// Configuration - Replace with your actual values
const CONFIG = {
  SPREADSHEET_ID: '1jI9g4BOgN946wgIneiNw6r0sBmloijNsPHexuxi77zY',
  FROM_EMAIL: 'pranto.ks@uttarauniversity.edu.bd',
  FROM_NAME: 'Cyber Security Club - Uttara University',
  SUBJECT: 'Application Received - Cyber Security Club'
};

/**
 * Main function to handle POST requests from the recruitment form
 * This replaces your current doPost function
 */
function doPost(e) {
  try {
    // Get the active spreadsheet
    var spreadsheet = SpreadsheetApp.openById(CONFIG.SPREADSHEET_ID);
    var sheet = spreadsheet.getActiveSheet();
    
    // Parse the incoming data
    var data = JSON.parse(e.postData.contents);
    
    // Add headers if this is the first row
    if (sheet.getLastRow() === 0) {
      var headers = [
        'Timestamp', 'First Name', 'Last Name', 'Student ID', 'Batch', 
        'Section', 'Department', 'Phone', 'Email', 'Experience', 
        'Interests', 'Motivation', 'Role', 'Availability', 'Skills', 'Agreement'
      ];
      sheet.getRange(1, 1, 1, headers.length).setValues([headers]);
      
      // Format headers
      sheet.getRange(1, 1, 1, headers.length)
        .setBackground('#4285F4')
        .setFontColor('#FFFFFF')
        .setFontWeight('bold');
    }
    
    // Add the data to the sheet
    var rowData = [
      data.timestamp || new Date().toISOString(),
      data.firstName,
      data.lastName,
      data.studentId,
      data.batch,
      data.section,
      data.department,
      data.phone,
      data.email,
      data.experience,
      data.interests,
      data.motivation,
      data.role,
      data.availability,
      data.skills,
      data.agreement
    ];
    
    sheet.appendRow(rowData);
    
    // Send confirmation email after successful data storage
    try {
      sendConfirmationEmail(data);
      console.log('Confirmation email sent to:', data.email);
    } catch (emailError) {
      console.error('Error sending confirmation email:', emailError);
      // Continue with success response even if email fails
    }
    
    return ContentService
      .createTextOutput(JSON.stringify({success: true, message: 'Application submitted successfully and confirmation email sent'}))
      .setMimeType(ContentService.MimeType.JSON);
      
  } catch (error) {
    console.error('Error processing application:', error);
    return ContentService
      .createTextOutput(JSON.stringify({success: false, message: error.toString()}))
      .setMimeType(ContentService.MimeType.JSON);
  }
}

/**
 * Send confirmation email to the applicant
 */
function sendConfirmationEmail(data) {
  try {
    console.log('📧 Starting sendConfirmationEmail for:', data.email);
    console.log('⚙️ Using CONFIG:', JSON.stringify(CONFIG, null, 2));
    
    console.log('🎨 Creating email template...');
    const emailTemplate = createEmailTemplate(data);
    console.log('✅ Email template created, length:', emailTemplate.length);
    
    console.log('📤 Preparing to send email with MailApp...');
    const emailOptions = {
      to: data.email,
      subject: CONFIG.SUBJECT,
      htmlBody: emailTemplate,
      name: CONFIG.FROM_NAME,
      replyTo: CONFIG.FROM_EMAIL
    };
    console.log('📋 Email options:', JSON.stringify(emailOptions, null, 2));
    
    console.log('🚀 Sending email via MailApp...');
    MailApp.sendEmail(emailOptions);
    
    console.log('✅ Confirmation email sent successfully to:', data.email);
    
  } catch (error) {
    console.error('❌ Error in sendConfirmationEmail - Step details:');
    console.error('❌ Target email:', data.email);
    console.error('❌ Error message:', error.message);
    console.error('❌ Error type:', error.name);
    console.error('❌ Full error:', error);
    console.error('❌ Stack trace:', error.stack);
    throw error;
  }
}

/**
 * Create HTML email template
 */
function createEmailTemplate(data) {
  const fullName = `${data.firstName} ${data.lastName}`;
  const currentDate = new Date().toLocaleDateString('en-US', {
    year: 'numeric',
    month: 'long',
    day: 'numeric'
  });
  
  return `
<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Application Confirmation - Cyber Security Club</title>
</head>
<body style="margin: 0; padding: 0; font-family: Arial, sans-serif; line-height: 1.6; background-color: #f5f5f5;">
    <div style="max-width: 650px; margin: 0 auto; background-color: #ffffff; border-radius: 10px; overflow: hidden; box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);">
        
        <!-- Header -->
        <div style="background-color: #ffffff; padding: 20px; text-align: center;">
            <img src="https://cybersecurity.club.uttara.ac.bd/assets/images/csc_blue.png" alt="Cyber Security Club Logo" style="width: 300px; height: auto;">
        </div>
        
        <!-- Content -->
        <div style="padding: 30px; background-color: #ffffff;">
            
            <!-- Success Badge -->
            <div style="background-color: #1e1e77; color: white; padding: 10px 15px; border-radius: 8px; font-weight: 600; font-size: 16px; margin-bottom: 25px; text-align: center;">
                Application Received Successfully!
            </div>
            
            <!-- Greeting -->
            <div style="font-size: 18px; color: #1f2937; margin-bottom: 20px; font-weight: 500;">
                Dear <strong>${fullName}</strong>,
            </div>
            
            <!-- Message -->
            <div style="color: #4b5563; margin-bottom: 25px; line-height: 1.7;">
                We have successfully received your application to join the <strong>Cyber Security Club</strong>. We're excited about your interest in cybersecurity and look forward to potentially welcoming you to our community of passionate security enthusiasts!
            </div>
            
            <!-- Application Details -->
            <div style="background-color: #f8fafc; border: 1px solid #e2e8f0; border-left: 4px solid #3b82f6; border-radius: 8px; padding: 20px; margin: 20px 0;">
                <h3 style="color: #1e40af; font-size: 18px; font-weight: 700; margin: 0 0 15px 0;">Application Summary</h3>
                
                <table style="width: 100%; border-collapse: collapse;">
                    <tr>
                        <td style="padding: 10px 0; border-bottom: 1px solid #e5e7eb; font-weight: 600; color: #374151;">Application Date</td>
                        <td style="padding: 10px 0; border-bottom: 1px solid #e5e7eb; color: #1d4ed8; font-weight: 500; text-align: right;">${currentDate}</td>
                    </tr>
                    <tr>
                        <td style="padding: 10px 0; border-bottom: 1px solid #e5e7eb; font-weight: 600; color: #374151;">Student ID</td>
                        <td style="padding: 10px 0; border-bottom: 1px solid #e5e7eb; color: #1d4ed8; font-weight: 500; text-align: right;">${data.studentId}</td>
                    </tr>
                    <tr>
                        <td style="padding: 10px 0; border-bottom: 1px solid #e5e7eb; font-weight: 600; color: #374151;">Contact Number</td>
                        <td style="padding: 10px 0; border-bottom: 1px solid #e5e7eb; color: #1d4ed8; font-weight: 500; text-align: right;">${data.phone}</td>
                    </tr>
                    <tr>
                        <td style="padding: 10px 0; border-bottom: 1px solid #e5e7eb; font-weight: 600; color: #374151;">Department</td>
                        <td style="padding: 10px 0; border-bottom: 1px solid #e5e7eb; color: #1d4ed8; font-weight: 500; text-align: right;">${data.department}</td>
                    </tr>
                    <tr>
                        <td style="padding: 10px 0; border-bottom: 1px solid #e5e7eb; font-weight: 600; color: #374151;">Batch & Section</td>
                        <td style="padding: 10px 0; border-bottom: 1px solid #e5e7eb; color: #1d4ed8; font-weight: 500; text-align: right;">Batch ${data.batch}, Section ${data.section}</td>
                    </tr>
                    <tr>
                        <td style="padding: 10px 0; border-bottom: 1px solid #e5e7eb; font-weight: 600; color: #374151;">Preferred Role</td>
                        <td style="padding: 10px 0; border-bottom: 1px solid #e5e7eb; color: #1d4ed8; font-weight: 500; text-align: right;">${data.role}</td>
                    </tr>
                    <tr>
                        <td style="padding: 10px 0; font-weight: 600; color: #374151;">Experience Level</td>
                        <td style="padding: 10px 0; color: #1d4ed8; font-weight: 500; text-align: right;">${data.experience}</td>
                    </tr>
                </table>
            </div>
            
            <!-- Next Steps -->
            <div style="background-color: #eff6ff; border: 1px solid #bfdbfe; border-radius: 8px; padding: 20px; margin: 20px 0;">
                <h3 style="color: #1e40af; font-size: 18px; font-weight: 700; margin: 0 0 15px 0;">What Happens Next?</h3>
                
                <div style="margin: 10px 0;">
                    <div style="display: inline-block; width: 25px; height: 25px; background-color: #3b82f6; color: white; border-radius: 50%; text-align: center; line-height: 25px; font-weight: bold; font-size: 12px; margin-right: 10px; vertical-align: top;">1</div>
                    <span style="color: #374151; font-size: 14px;">Our team will review your application within 3-5 days</span>
                </div>
                
                <div style="margin: 10px 0;">
                    <div style="display: inline-block; width: 25px; height: 25px; background-color: #3b82f6; color: white; border-radius: 50%; text-align: center; line-height: 25px; font-weight: bold; font-size: 12px; margin-right: 10px; vertical-align: top;">2</div>
                    <span style="color: #374151; font-size: 14px;">You'll receive an email invitation to our next Meet & Greet session</span>
                </div>
                
                <div style="margin: 10px 0;">
                    <div style="display: inline-block; width: 25px; height: 25px; background-color: #3b82f6; color: white; border-radius: 50%; text-align: center; line-height: 25px; font-weight: bold; font-size: 12px; margin-right: 10px; vertical-align: top;">3</div>
                    <span style="color: #374151; font-size: 14px;">Attend the informal meeting to learn more about our club activities</span>
                </div>
                
                <div style="margin: 10px 0;">
                    <div style="display: inline-block; width: 25px; height: 25px; background-color: #3b82f6; color: white; border-radius: 50%; text-align: center; line-height: 25px; font-weight: bold; font-size: 12px; margin-right: 10px; vertical-align: top;">4</div>
                    <span style="color: #374151; font-size: 14px;">Join our social media groups to connect with other members</span>
                </div>
                
                <div style="margin: 10px 0;">
                    <div style="display: inline-block; width: 25px; height: 25px; background-color: #3b82f6; color: white; border-radius: 50%; text-align: center; line-height: 25px; font-weight: bold; font-size: 12px; margin-right: 10px; vertical-align: top;">5</div>
                    <span style="color: #374151; font-size: 14px;">Start participating in club activities and workshops!</span>
                </div>
            </div>
            
            <!-- Important Note -->
            <div style="background-color: #fef3c7; border: 1px solid #f59e0b; border-radius: 8px; padding: 15px; margin: 20px 0; color: #92400e; font-size: 14px;">
                <strong>Important:</strong> Please save this email for your records. You may need to reference your application details during the review process.
            </div>
            
            <!-- Signature -->
            <div style="margin-top: 25px; padding-top: 20px; border-top: 2px solid #f1f5f9; color: #374151; line-height: 1.7;">
                We appreciate your interest in cybersecurity and look forward to potentially having you as part of our cybersecurity family!<br><br>
                Best regards,<br>
                <strong>The Cyber Security Club Team</strong><br>
                Uttara University
            </div>
        </div>
        
        <!-- Footer -->
        <div style="background-color: #1e293b; color: #e2e8f0; padding: 20px; text-align: center; font-size: 13px;">
            <div>© 2025 Cyber Security Club, Uttara University</div>
            <div style="margin-top: 10px; opacity: 0.8;">This is an automated message. Please do not reply directly to this email.</div>
            <div style="margin-top: 10px;;">
                <a href="https://facebook.com/csc.uu.bd" style="display: inline-block;color: white; text-decoration: none; margin-left: 10px; margin-right: 10px;">Facebook</a>
                <a href="https://www.linkedin.com/in/cscuu" style="display: inline-block;color: white; text-decoration: none; margin-left: 10px; margin-right: 10px;">LinkedIn</a>
                <a href="https://discord.gg/N83SjBHjzG" style="display: inline-block;color: white; text-decoration: none; margin-left: 10px; margin-right: 10px;">Discord</a>
            </div>
        </div>
    </div>
</body>
</html>`;
}

/**
 * TESTING FUNCTIONS - Use these to test email functionality
 * Run these functions in Google Apps Script to verify everything works
 */

/**
 * STEP 1: Test basic email functionality first
 */
function testBasicEmail() {
  try {
    MailApp.sendEmail({
      to: 'prantokumar.net@gmail.com',
      subject: 'Test Email - CSC Recruitment System',
      body: 'Hello! This is a test to verify basic email functionality is working. If you receive this, the system is ready!'
    });
    
    console.log('✅ Basic email test successful');
    return 'Basic email sent successfully!';
    
  } catch (error) {
    console.error('❌ Basic email test failed:', error);
    return 'Basic email failed: ' + error.toString();
  }
}

/**
 * STEP 2: Test the full HTML email template
 */
function testFullEmailTemplate() {
  try {
    console.log('🧪 Starting HTML email template test...');
    
    const testData = {
      firstName: 'Test',
      lastName: 'Applicant',
      studentId: 'TEST-001',
      department: 'Computer Science & Engineering',
      batch: '60',
      section: 'A',
      role: 'Active Member',
      experience: 'Beginner',
      email: 'prantokumar.net@gmail.com'
    };
    
    console.log('📝 Test data prepared:', JSON.stringify(testData, null, 2));
    
    console.log('📧 Creating email template...');
    const template = createEmailTemplate(testData);
    console.log('✅ Email template created successfully');
    
    console.log('📤 Sending confirmation email...');
    sendConfirmationEmail(testData);
    console.log('✅ Full email template test successful');
    return 'HTML email sent successfully!';
    
  } catch (error) {
    console.error('❌ Full email template test failed at step:', error.message);
    console.error('❌ Full error details:', error);
    console.error('❌ Error stack:', error.stack);
    return 'HTML email failed: ' + error.toString();
  }
}

/**
 * Check email quota and permissions
 */
function checkEmailStatus() {
  try {
    const quota = MailApp.getRemainingDailyQuota();
    console.log('📊 Daily email quota remaining:', quota);
    
    return `Email system status: Active | Quota remaining: ${quota} emails`;
    
  } catch (error) {
    console.error('❌ Error checking email status:', error);
    return 'Email status check failed: ' + error.toString();
  }
}

/**
 * STEP 2B: Alternative simple HTML email test
 */
function testSimpleHTMLEmail() {
  try {
    console.log('🧪 Testing simple HTML email...');
    
    const simpleHTML = `
      <div style="font-family: Arial, sans-serif; padding: 20px;">
        <h2 style="color: #4285F4;">Test Email</h2>
        <p>This is a simple HTML email test.</p>
        <p><strong>If you receive this, HTML emails are working!</strong></p>
      </div>
    `;
    
    MailApp.sendEmail({
      to: 'prantokumar.net@gmail.com',
      subject: 'Simple HTML Test - CSC',
      htmlBody: simpleHTML,
      name: 'CSC Test System'
    });
    
    console.log('✅ Simple HTML email sent successfully');
    return 'Simple HTML email sent successfully!';
    
  } catch (error) {
    console.error('❌ Simple HTML email test failed:', error);
    return 'Simple HTML email failed: ' + error.toString();
  }
}

/**
 * RUN THIS FUNCTION - Complete test suite
 * This will run all tests in sequence and show results
 */
function runAllTests() {
  console.log('🚀 Starting complete email system test...\n');
  
  try {
    // Test 1: Basic email
    console.log('📧 Test 1: Basic Email...');
    const test1Result = testBasicEmail();
    console.log('Result:', test1Result);
    console.log('---\n');
    
    // Test 2: Simple HTML
    console.log('🎨 Test 2: Simple HTML Email...');
    const test2Result = testSimpleHTMLEmail();
    console.log('Result:', test2Result);
    console.log('---\n');
    
    // Test 3: Full template
    console.log('🌟 Test 3: Full HTML Template...');
    const test3Result = testFullEmailTemplate();
    console.log('Result:', test3Result);
    console.log('---\n');
    
    // Test 4: Check status
    console.log('📊 Test 4: Email Status Check...');
    const test4Result = checkEmailStatus();
    console.log('Result:', test4Result);
    console.log('---\n');
    
    console.log('✅ All tests completed! Check your email inbox.');
    return 'All tests completed successfully!';
    
  } catch (error) {
    console.error('❌ Test suite failed:', error);
    return 'Test suite failed: ' + error.toString();
  }
}
