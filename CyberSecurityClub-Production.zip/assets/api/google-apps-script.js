/**
 * Google Apps Script for Cyber Security Club Recruitment Form
 * This script handles form submissions and sends confirmation emails
 */

// Configuration - Replace with your actual values
const CONFIG = {
  SPREADSHEET_ID: '1jI9g4BOgN946wgIneiNw6r0sBmloijNsPHexuxi77zY', // Replace with your Google Sheets ID
  SHEET_NAME: 'Applications Form - Cyber Security Club, Uttara University | 2025', // Name of the sheet tab
  FROM_EMAIL: 'prantokumar.net@gmail.com', // Your club email
  FROM_NAME: 'Cyber Security Club - Uttara University',
  SUBJECT: 'Application Received - Cyber Security Club'
};

/**
 * Main function to handle POST requests from the recruitment form
 * Modified to include email confirmation while maintaining existing data storage
 */
function doPost(e) {
  try {
    // Get the active spreadsheet (create one first if needed)
    var spreadsheet = SpreadsheetApp.openById('1jI9g4BOgN946wgIneiNw6r0sBmloijNsPHexuxi77zY');
    var sheet = spreadsheet.getActiveSheet();
    
    // Parse the incoming data
    var data = JSON.parse(e.postData.contents);
    
    // Add headers if this is the first row
    if (sheet.getLastRow() === 0) {
      var headers = [
        'Timestamp', 'First Name', 'Last Name', 'Student ID', 'Batch', 
        'Section', 'Department', 'Phone', 'Email', 'Experience', 
        'Interests', 'Motivation', 'Role', 'Availability', 'Skills', 'Agreement'
      ];
      sheet.getRange(1, 1, 1, headers.length).setValues([headers]);
      
      // Format headers
      sheet.getRange(1, 1, 1, headers.length)
        .setBackground('#4285F4')
        .setFontColor('#FFFFFF')
        .setFontWeight('bold');
    }
    
    // Add the data to the sheet
    var rowData = [
      data.timestamp || new Date().toISOString(),
      data.firstName,
      data.lastName,
      data.studentId,
      data.batch,
      data.section,
      data.department,
      data.phone,
      data.email,
      data.experience,
      data.interests,
      data.motivation,
      data.role,
      data.availability,
      data.skills,
      data.agreement
    ];
    
    sheet.appendRow(rowData);
    
    // Send confirmation email after successful data storage
    try {
      sendConfirmationEmail(data);
      console.log('Confirmation email sent to:', data.email);
    } catch (emailError) {
      console.error('Error sending confirmation email:', emailError);
      // Continue with success response even if email fails
    }
    
    return ContentService
      .createTextOutput(JSON.stringify({success: true, message: 'Application submitted successfully and confirmation email sent'}))
      .setMimeType(ContentService.MimeType.JSON);
      
  } catch (error) {
    console.error('Error processing application:', error);
    return ContentService
      .createTextOutput(JSON.stringify({success: false, message: error.toString()}))
      .setMimeType(ContentService.MimeType.JSON);
  }
}

/**
 * STEP 1: Simple email test with basic MailApp - Test this first!
 */
function simpleEmailTest() {
  try {
    console.log('Starting simple email test...');
    
    MailApp.sendEmail({
      to: 'prantokumar.net@gmail.com',
      subject: 'Test Email from Google Apps Script - CSC',
      body: 'Hello! This is a simple test email to verify that Google Apps Script can send emails successfully. If you receive this, the basic email functionality is working.'
    });
    
    console.log('✅ Simple test email sent successfully to: prantokumar.net@gmail.com');
    return 'Email sent successfully!';
    
  } catch (error) {
    console.error('❌ Error sending simple test email:', error);
    return 'Email failed: ' + error.toString();
  }
}

/**
 * STEP 2: Test the HTML email template - Run this second!
 */
function testHTMLEmail() {
  try {
    console.log('Starting HTML email test...');
    
    const testData = {
      firstName: 'Test',
      lastName: 'User',
      studentId: 'TEST-001',
      department: 'Computer Science & Engineering',
      batch: '60',
      section: 'A',
      role: 'Active Member',
      experience: 'Beginner',
      email: 'prantokumar.net@gmail.com'
    };
    
    sendConfirmationEmail(testData);
    console.log('✅ HTML test email sent successfully');
    return 'HTML Email sent successfully!';
    
  } catch (error) {
    console.error('❌ Error sending HTML test email:', error);
    return 'HTML Email failed: ' + error.toString();
  }
}

/**
 * STEP 3: Check Gmail quota and permissions - Run this if emails fail!
 */
function checkEmailQuota() {
  try {
    const quota = MailApp.getRemainingDailyQuota();
    console.log('📊 Remaining daily email quota:', quota);
    
    return `Quota remaining: ${quota} emails. Gmail access: Working`;
    
  } catch (error) {
    console.error('❌ Error checking quota/permissions:', error);
    return 'Quota check failed: ' + error.toString();
  }
}

/**
 * Send confirmation email to the applicant
 */
function sendConfirmationEmail(data) {
  try {
    console.log('Creating email template for:', data.email);
    const emailTemplate = createEmailTemplate(data);
    
    console.log('Sending email with config:', {
      to: data.email,
      subject: CONFIG.SUBJECT,
      from: CONFIG.FROM_EMAIL,
      name: CONFIG.FROM_NAME
    });
    
    MailApp.sendEmail({
      to: data.email,
      subject: CONFIG.SUBJECT,
      htmlBody: emailTemplate,
      name: CONFIG.FROM_NAME,
      replyTo: CONFIG.FROM_EMAIL
    });
    
    console.log('✅ Confirmation email sent successfully to:', data.email);
    
  } catch (error) {
    console.error('❌ Error sending confirmation email to', data.email, ':', error);
    throw error; // Re-throw to let caller handle it
  }
}

/**
 * Create HTML email template
 */
function createEmailTemplate(data) {
  const fullName = `${data.firstName} ${data.lastName}`;
  const currentDate = new Date().toLocaleDateString('en-US', {
    year: 'numeric',
    month: 'long',
    day: 'numeric'
  });
  
  return `
<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Application Confirmation</title>
    <style>
        body {
            margin: 0;
            padding: 0;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            line-height: 1.6;
            color: #333333;
            background-color: #f8f9fa;
        }
        .container {
            max-width: 600px;
            margin: 0 auto;
            background-color: #ffffff;
            border-radius: 10px;
            overflow: hidden;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
        }
        .header {
            background: linear-gradient(135deg, #667eea, #764ba2);
            color: white;
            padding: 30px 20px;
            text-align: center;
        }
        .header h1 {
            margin: 0;
            font-size: 24px;
            font-weight: 600;
        }
        .header p {
            margin: 5px 0 0 0;
            opacity: 0.9;
            font-size: 16px;
        }
        .content {
            padding: 30px 20px;
        }
        .welcome-message {
            background-color: #e8f5e8;
            border-left: 4px solid #4caf50;
            padding: 15px;
            margin-bottom: 25px;
            border-radius: 4px;
        }
        .welcome-message h2 {
            margin: 0 0 10px 0;
            color: #2e7d32;
            font-size: 18px;
        }
        .details-section {
            background-color: #f8f9fa;
            padding: 20px;
            border-radius: 8px;
            margin: 20px 0;
        }
        .details-section h3 {
            margin: 0 0 15px 0;
            color: #495057;
            font-size: 16px;
        }
        .detail-row {
            display: flex;
            justify-content: space-between;
            padding: 8px 0;
            border-bottom: 1px solid #dee2e6;
        }
        .detail-row:last-child {
            border-bottom: none;
        }
        .detail-label {
            font-weight: 600;
            color: #495057;
        }
        .detail-value {
            color: #6c757d;
            text-align: right;
            max-width: 60%;
        }
        .next-steps {
            background-color: #fff3cd;
            border: 1px solid #ffeaa7;
            border-radius: 8px;
            padding: 20px;
            margin: 20px 0;
        }
        .next-steps h3 {
            margin: 0 0 15px 0;
            color: #856404;
        }
        .step {
            margin: 10px 0;
            padding-left: 20px;
            position: relative;
        }
        .step::before {
            content: "→";
            position: absolute;
            left: 0;
            color: #667eea;
            font-weight: bold;
        }
        .contact-info {
            background-color: #e3f2fd;
            border-radius: 8px;
            padding: 20px;
            margin: 20px 0;
            text-align: center;
        }
        .contact-info h3 {
            margin: 0 0 15px 0;
            color: #1565c0;
        }
        .social-links {
            margin: 15px 0;
        }
        .social-links a {
            display: inline-block;
            margin: 0 10px;
            color: #667eea;
            text-decoration: none;
            font-weight: 500;
        }
        .footer {
            background-color: #343a40;
            color: #ffffff;
            padding: 20px;
            text-align: center;
            font-size: 14px;
        }
        .footer a {
            color: #adb5bd;
            text-decoration: none;
        }
        @media (max-width: 600px) {
            .detail-row {
                flex-direction: column;
            }
            .detail-value {
                text-align: left;
                max-width: 100%;
                margin-top: 5px;
            }
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="header">
            <h1>🛡️ Cyber Security Club</h1>
            <p>Uttara University</p>
        </div>
        
        <div class="content">
            <div class="welcome-message">
                <h2>✅ Application Received Successfully!</h2>
                <p>Thank you for your interest in joining the Cyber Security Club at Uttara University.</p>
            </div>
            
            <p>Dear <strong>${fullName}</strong>,</p>
            
            <p>We have successfully received your application to join the Cyber Security Club. We're excited about your interest in cybersecurity and look forward to potentially welcoming you to our community of passionate security enthusiasts!</p>
            
            <div class="details-section">
                <h3>📋 Application Summary</h3>
                <div class="detail-row">
                    <span class="detail-label">Application Date:</span>
                    <span class="detail-value">${currentDate}</span>
                </div>
                <div class="detail-row">
                    <span class="detail-label">Student ID:</span>
                    <span class="detail-value">${data.studentId}</span>
                </div>
                <div class="detail-row">
                    <span class="detail-label">Department:</span>
                    <span class="detail-value">${data.department}</span>
                </div>
                <div class="detail-row">
                    <span class="detail-label">Batch & Section:</span>
                    <span class="detail-value">Batch ${data.batch}, Section ${data.section}</span>
                </div>
                <div class="detail-row">
                    <span class="detail-label">Preferred Role:</span>
                    <span class="detail-value">${data.role}</span>
                </div>
                <div class="detail-row">
                    <span class="detail-label">Experience Level:</span>
                    <span class="detail-value">${data.experience}</span>
                </div>
            </div>
            
            <div class="next-steps">
                <h3>🚀 What Happens Next?</h3>
                <div class="step">Our team will review your application within 3-5 business days</div>
                <div class="step">You'll receive an email invitation to our next Meet & Greet session</div>
                <div class="step">Attend the informal meeting to learn more about our club activities</div>
                <div class="step">Complete the new member orientation (if accepted)</div>
                <div class="step">Start participating in club activities and workshops!</div>
            </div>
            
            <div class="contact-info">
                <h3>📧 Questions or Concerns?</h3>
                <p>If you have any questions about your application or our club activities, please don't hesitate to reach out:</p>
                <p><strong>Email:</strong> cybersecurity@club.uttara.ac.bd</p>
                <div class="social-links">
                    <a href="https://facebook.com/csc.uu.bd">Facebook</a>
                    <a href="https://www.linkedin.com/in/cscuu">LinkedIn</a>
                    <a href="https://discord.gg/N83SjBHjzG">Discord</a>
                </div>
            </div>
            
            <p><strong>Important:</strong> Please save this email for your records. You may need to reference your application details during the review process.</p>
            
            <p>We appreciate your interest in cybersecurity and look forward to potentially having you as part of our cybersecurity family!</p>
            
            <p>Best regards,<br>
            <strong>The Cyber Security Club Team</strong><br>
            Uttara University</p>
        </div>
        
        <div class="footer">
            <p>© 2025 Cyber Security Club, Uttara University</p>
            <p>This is an automated message. Please do not reply directly to this email.</p>
            <p><a href="mailto:cybersecurity@club.uttara.ac.bd">Contact Us</a> | <a href="https://cybersecurity.club.uttara.ac.bd">Visit Website</a></p>
        </div>
    </div>
</body>
</html>`;
}

/**
 * Test function to verify email template (Legacy - use testHTMLEmail instead)
 */
function testEmailTemplate() {
  const testData = {
    firstName: 'John',
    lastName: 'Doe',
    studentId: '2021-1-60-001',
    department: 'Computer Science & Engineering',
    batch: '60',
    section: 'A',
    role: 'Active Member',
    experience: 'Beginner',
    email: 'prantokumar.net@gmail.com'  // Changed to your email for testing
  };
  
  const template = createEmailTemplate(testData);
  console.log('Email template generated successfully');
  
  // Send test email to your own address
  try {
    sendConfirmationEmail(testData);
    console.log('Test email sent successfully to: ' + testData.email);
  } catch (error) {
    console.error('Error sending test email:', error);
  }
}

/**
 * Simple email test with basic MailApp
 */
function simpleEmailTest() {
  try {
    MailApp.sendEmail({
      to: 'prantokumar.net@gmail.com',
      subject: 'Test Email from Google Apps Script',
      body: 'This is a simple test email to verify email functionality is working.'
    });
    console.log('Simple test email sent successfully');
  } catch (error) {
    console.error('Error sending simple test email:', error);
  }
}

/**
 * Function to manually send emails to existing applications (if needed)
 * Updated to work with your existing sheet structure with better debugging
 */
function sendEmailsToExistingApplications() {
  try {
    console.log('Starting to send emails to existing applications...');
    
    const spreadsheet = SpreadsheetApp.openById('1jI9g4BOgN946wgIneiNw6r0sBmloijNsPHexuxi77zY');
    const sheet = spreadsheet.getActiveSheet();
    
    console.log('Sheet name:', sheet.getName());
    console.log('Number of rows:', sheet.getLastRow());
    
    if (sheet.getLastRow() === 0) {
      console.log('No data found in sheet');
      return;
    }
    
    const data = sheet.getDataRange().getValues();
    const headers = data[0];
    
    console.log('Headers found:', headers);
    
    // Find email column index
    const emailColumnIndex = headers.indexOf('Email');
    
    if (emailColumnIndex === -1) {
      console.log('Email column not found. Available headers:', headers);
      return;
    }
    
    console.log('Email column found at index:', emailColumnIndex);
    console.log('Total rows to process:', data.length - 1);
    
    let emailsSent = 0;
    let emailsFailed = 0;
    
    // Process each row (skip header)
    for (let i = 1; i < data.length; i++) {
      const row = data[i];
      const email = row[emailColumnIndex];
      
      console.log(`Processing row ${i}: ${email}`);
      
      if (email && email.trim() !== '') {
        try {
          const applicationData = {
            firstName: row[headers.indexOf('First Name')] || '',
            lastName: row[headers.indexOf('Last Name')] || '',
            studentId: row[headers.indexOf('Student ID')] || '',
            department: row[headers.indexOf('Department')] || '',
            batch: row[headers.indexOf('Batch')] || '',
            section: row[headers.indexOf('Section')] || '',
            role: row[headers.indexOf('Role')] || '',
            experience: row[headers.indexOf('Experience')] || '',
            email: email.trim()
          };
          
          console.log('Sending email to:', applicationData.email);
          console.log('Applicant data:', applicationData);
          
          sendConfirmationEmail(applicationData);
          emailsSent++;
          console.log(`✅ Email sent successfully to: ${email}`);
          
          // Add delay to avoid rate limiting
          Utilities.sleep(2000); // Increased to 2 seconds
          
        } catch (emailError) {
          emailsFailed++;
          console.error(`❌ Failed to send email to ${email}:`, emailError);
        }
      } else {
        console.log(`Skipping row ${i}: Empty email`);
      }
    }
    
    console.log(`\n📊 Email Summary:`);
    console.log(`Total emails sent: ${emailsSent}`);
    console.log(`Total emails failed: ${emailsFailed}`);
    console.log(`Total rows processed: ${data.length - 1}`);
    
  } catch (error) {
    console.error('Error in sendEmailsToExistingApplications:', error);
  }
}

/**
 * ALTERNATIVE: Minimal update to your existing doPost function
 * Use this if you want to keep your current logic but add email functionality
 */
function doPostWithEmail(e) {
  try {
    // Get the active spreadsheet (create one first if needed)
    var spreadsheet = SpreadsheetApp.openById('1jI9g4BOgN946wgIneiNw6r0sBmloijNsPHexuxi77zY');
    var sheet = spreadsheet.getActiveSheet();
    
    // Parse the incoming data
    var data = JSON.parse(e.postData.contents);
    
    // Add headers if this is the first row
    if (sheet.getLastRow() === 0) {
      var headers = [
        'Timestamp', 'First Name', 'Last Name', 'Student ID', 'Batch', 
        'Section', 'Department', 'Phone', 'Email', 'Experience', 
        'Interests', 'Motivation', 'Role', 'Availability', 'Skills', 'Agreement'
      ];
      sheet.getRange(1, 1, 1, headers.length).setValues([headers]);
    }
    
    // Add the data to the sheet (your original logic)
    var rowData = [
      data.timestamp || new Date().toISOString(), // Added: Auto-timestamp
      data.firstName,
      data.lastName,
      data.studentId,
      data.batch,
      data.section,
      data.department,
      data.phone,
      data.email,
      data.experience,
      data.interests,
      data.motivation,
      data.role,
      data.availability,
      data.skills,
      data.agreement
    ];
    
    sheet.appendRow(rowData);
    
    // NEW: Send confirmation email
    try {
      sendConfirmationEmail(data);
      console.log('Confirmation email sent to:', data.email);
    } catch (emailError) {
      console.error('Error sending confirmation email:', emailError);
      // Continue with success even if email fails
    }
    
    return ContentService
      .createTextOutput(JSON.stringify({success: true, message: 'Application submitted successfully and confirmation email sent'}))
      .setMimeType(ContentService.MimeType.JSON);
      
  } catch (error) {
    return ContentService
      .createTextOutput(JSON.stringify({success: false, message: error.toString()}))
      .setMimeType(ContentService.MimeType.JSON);
  }
}
